import admindashblue from "./admindashblue.png"
import admindashred from "./admindashred.png"
import dummyadmin from "./dummyadmin.png"

export { admindashblue,admindashred ,dummyadmin}