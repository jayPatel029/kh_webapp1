const server_url = "http://localhost:8080/api";

export { server_url };
export const adminEmail = "superadmin@kifaytihealth.com";
