export const readingTypes = [
    "Int",
    "Decimal",
    "Time",
    "Date",
    "Yes/No",
    "Upload",
    "Text",
]