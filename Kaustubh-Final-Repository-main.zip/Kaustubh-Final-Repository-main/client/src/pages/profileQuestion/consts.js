  export const questionTypes = [
    { value: "Yes/No", label: "Yes/No" },
    { value: "Date", label: "Date" },
    { value: "MultipleChoice", label: "MultipleChoice" },
    { value: "Text", label: "Text" },
    { value: "SelectAnyOne", label: "SelectAnyOne" },
    { value: "Numeric", label: "Numeric" }
  ];