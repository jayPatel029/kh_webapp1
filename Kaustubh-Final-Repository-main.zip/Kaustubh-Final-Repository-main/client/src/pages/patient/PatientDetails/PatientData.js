const patientData = [
  {
    id: 1,
    name: "Sujal",
    number: 7021836572,
  },
  {
    id: 2,
    name: "John Doe",
    number: 1234567890,
  },
  {
    id: 3,
    name: "Aisha",
    number: 9876543210,
  },
  {
    id: 4,
    name: "Carlos",
    number: 3456789012,
  },
  {
    id: 5,
    name: "Emily",
    number: 8901234567,
  },
  {
    id: 6,
    name: "Rajesh",
    number: 5678901234,
  },
  {
    id: 7,
    name: "Sophie",
    number: 2109876543,
  },
  {
    id: 8,
    name: "Daniel",
    number: 4321098765,
  },
  {
    id: 9,
    name: "Mia",
    number: 6789012345,
  },
  {
    id: 10,
    name: "Alejandro",
    number: 7890123456,
  },
  {
    id: 11,
    name: "Lily",
    number: 5432109876,
  },
  {
    id: 12,
    name: "Kumar",
    number: 1230987654,
  },
  {
    id: 13,
    name: "Grace",
    number: 4567890123,
  },
  {
    id: 14,
    name: "Omar",
    number: 6789012345,
  },
  {
    id: 15,
    name: "Isabella",
    number: 8901234567,
  },
  {
    id: 16,
    name: "Elijah",
    number: 2345678901,
  },
  {
    id: 17,
    name: "Zara",
    number: 5678901234,
  },
  {
    id: 18,
    name: "Nathan",
    number: 8765432109,
  },
  {
    id: 19,
    name: "Amelia",
    number: 1098765432,
  },
  {
    id: 20,
    name: "Aiden",
    number: 3210987654,
  },
  {
    id: 21,
    name: "Chloe",
    number: 5432109876,
  },
  {
    id: 22,
    name: "David",
    number: 7654321098,
  },
  {
    id: 23,
    name: "Emma",
    number: 9876543210,
  },
  {
    id: 24,
    name: "Liam",
    number: 2109876543,
  },
  {
    id: 25,
    name: "Aria",
    number: 4321098765,
  },
  {
    id: 26,
    name: "Owen",
    number: 6543210987,
  },
  {
    id: 27,
    name: "Hannah",
    number: 8765432109,
  },
  {
    id: 28,
    name: "Ethan",
    number: 1098765432,
  },
  {
    id: 29,
    name: "Olivia",
    number: 3210987654,
  },
  {
    id: 30,
    name: "Jackson",
    number: 5432109876,
  },
  {
    id: 31,
    name: "Ava",
    number: 7654321098,
  },
  {
    id: 32,
    name: "Lucas",
    number: 9876543210,
  },
  {
    id: 33,
    name: "Ella",
    number: 2109876543,
  },
  {
    id: 34,
    name: "Noah",
    number: 4321098765,
  },
  {
    id: 35,
    name: "Madison",
    number: 6543210987,
  },
  {
    id: 36,
    name: "Caleb",
    number: 8765432109,
  },
  {
    id: 37,
    name: "Avery",
    number: 1098765432,
  },
  {
    id: 38,
    name: "Henry",
    number: 3210987654,
  },
  {
    id: 39,
    name: "Scarlett",
    number: 5432109876,
  },
  {
    id: 40,
    name: "Mason",
    number: 7654321098,
  },
  {
    id: 41,
    name: "Grace",
    number: 9876543210,
  },
  {
    id: 42,
    name: "Eli",
    number: 2109876543,
  },
  {
    id: 43,
    name: "Luna",
    number: 4321098765,
  },
  {
    id: 44,
    name: "Logan",
    number: 6543210987,
  },
  {
    id: 45,
    name: "Mila",
    number: 8765432109,
  },
  {
    id: 46,
    name: "William",
    number: 1098765432,
  },
  {
    id: 47,
    name: "Sophia",
    number: 3210987654,
  },
  {
    id: 48,
    name: "Aiden",
    number: 5432109876,
  },
  {
    id: 49,
    name: "Harper",
    number: 7654321098,
  },
  {
    id: 50,
    name: "Carter",
    number: 9876543210,
  },
  {
    id: 51,
    name: "Natalie",
    number: 2109876543,
  },
  {
    id: 52,
    name: "Jayden",
    number: 4321098765,
  },
];

export default patientData;
