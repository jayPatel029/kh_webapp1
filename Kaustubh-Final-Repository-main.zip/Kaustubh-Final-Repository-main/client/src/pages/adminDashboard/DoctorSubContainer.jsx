import React from 'react'

const DoctorSubContainer = ({patientName,Alerts}) => {
  return (
    <div>DoctorSubContainer</div>
  )
}

export default DoctorSubContainer