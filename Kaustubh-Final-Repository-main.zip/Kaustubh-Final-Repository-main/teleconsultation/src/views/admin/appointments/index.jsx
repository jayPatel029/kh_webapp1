/*!
  _   _  ___  ____  ___ ________  _   _   _   _ ___   
 | | | |/ _ \|  _ \|_ _|__  / _ \| \ | | | | | |_ _| 
 | |_| | | | | |_) || |  / / | | |  \| | | | | || | 
 |  _  | |_| |  _ < | | / /| |_| | |\  | | |_| || |
 |_| |_|\___/|_| \_\___/____\___/|_| \_|  \___/|___|
                                                                                                                                                                                                                                                                                                                                       
=========================================================
* Horizon UI - v1.1.0
=========================================================

* Product Page: https://www.horizon-ui.com/
* Copyright 2023 Horizon UI (https://www.horizon-ui.com/)

* Designed and Coded by Simmmple

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/

// Chakra imports
import {
  Avatar,
  Box,
  Flex,
  Stack,
  FormLabel,
  Icon,
  Input,
  Select,
  SimpleGrid,
  useColorModeValue,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
  Textarea,
  InputGroup,InputRightAddon,InputRightElement
} from "@chakra-ui/react";
// Assets
import Usa from "assets/img/dashboards/usa.png";
// Custom components
import MiniCalendar from "components/calendar/MiniCalendar";
import MiniStatistics from "components/card/MiniStatistics";
import IconBox from "components/icons/IconBox";
import React,{useState} from "react";
import {
  MdAddTask,
  MdAttachMoney,
  MdBarChart,
  MdFileCopy,
} from "react-icons/md";
import CheckTable from "views/admin/default/components/CheckTable";
import ComplexTable from "views/admin/default/components/ComplexTable";
import DailyTraffic from "views/admin/default/components/DailyTraffic";
import PieCard from "views/admin/default/components/PieCard";
import Tasks from "views/admin/default/components/Tasks";
import TotalSpent from "views/admin/default/components/TotalSpent";
import WeeklyRevenue from "views/admin/default/components/WeeklyRevenue";
import {
  columnsDataCheck,
  columnsDataComplex,
  appointmentcolumnsDataComplex,
} from "views/admin/default/variables/columnsData";
import tableDataCheck from "views/admin/default/variables/tableDataCheck.json";
import tableDataComplex from "views/admin/default/variables/tableDataComplex.json";
import axiosInstance from "../axios/axiosInstance"
import { MdDateRange } from 'react-icons/md';
export default function UserReports() {
  // Chakra Color Mode
  const brandColor = useColorModeValue("brand.500", "white");
  const boxBg = useColorModeValue("secondaryGray.300", "whiteAlpha.100");

  // Dummy data for filter options (can be dynamic based on your backend or other logic)
  const doctors = [
    { value: "Dr. Smith", label: "Dr. Smith" },
    { value: "Dr. Johnson", label: "Dr. Johnson" },
    { value: "Dr. White", label: "Dr. White" },
    { value: "Dr. Black", label: "Dr. Black" },
    { value: "Dr. Green", label: "Dr. Green" },
  ];
  const { isOpen, onOpen, onClose } = useDisclosure();
  const { isOpen: isFormOpen, onOpen: onFormOpen, onClose: onFormClose } = useDisclosure();
  // Dummy data for month and year options
  const monthOptions = [
    { value: "01", label: "January" },
    { value: "02", label: "February" },
    { value: "03", label: "March" },
    { value: "04", label: "April" },
    { value: "05", label: "May" },
    { value: "06", label: "June" },
    { value: "07", label: "July" },
    { value: "08", label: "August" },
    { value: "09", label: "September" },
    { value: "10", label: "October" },
    { value: "11", label: "November" },
    { value: "12", label: "December" },
  ];
  const [patientsData, setPatientsData] = useState([]);
  const [newPatientData, setNewPatientData] = useState({
    id: "",
    profilePhoto: null,
    name: "",
    age: "",
    gender: "",
    email: "",
    phoneNumber: "",
    test: "",
    date: "",
    result: "",
    pastAppointments: "",
  });
  const yearOptions = [
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
    { value: "2024", label: "2024" },
    { value: "2025", label: "2025" },
    // Add more years as needed
  ];

  // Handler functions for filters (to be implemented based on your logic)
  const handleFromDateChange = (e) => {
    // Handle from date change
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewPatientData({ ...newPatientData, [name]: value });
  };

  const handleFileChange = (e) => {
    setNewPatientData({ ...newPatientData, profilePhoto: e.target.files[0] });
  };
  const handleToDateChange = (e) => {
    // Handle to date change
  };

  const handleDoctorChange = (selectedOption) => {
    // Handle doctor change
  };

  const handlePaymentStatusChange = (e) => {
    // Handle payment status change
  };
  const handleAddPatient = async () => {
    try {
      const patientData = {
        id: newPatientData.id,
        profilePhoto: newPatientData.profilePhoto, // Note: If you're sending a file, handle it separately
        name: newPatientData.name,
        age: newPatientData.age,
        gender: newPatientData.gender,
        email: newPatientData.email,
        number: newPatientData.phoneNumber,
        test: newPatientData.test,
        date: newPatientData.date,
        result: newPatientData.result,
        pastAppointments: newPatientData.pastAppointments,
      };
  
      // Log the patientData for debugging
      console.log("Patient Data:", patientData);
  
      await axiosInstance.post("http://localhost:8080/api/patient/AddPatient", {patientData})  
  
      // Fetch updated patients data after adding new patient
      const response = await axiosInstance.get("http://localhost:8080/api/patient/getPatients");
      setPatientsData(response.data.data);
      onFormClose();
    } catch (error) {
      console.error("Error adding new patient:", error);
    }
  };
  
  
  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }} w="100%" overflowX="auto">
     
      <SimpleGrid columns={1} gap="20px">
      <ComplexTable columnsData={appointmentcolumnsDataComplex} tableData={tableDataComplex} isAppointment={true} />
      </SimpleGrid>
      <Flex justify="flex-end" mt="4">
    <Button colorScheme="teal" onClick={onFormOpen}>
      Add Patients
    </Button>
  </Flex>
  <Modal isOpen={isFormOpen} onClose={onFormClose}>
        <ModalOverlay />
        <ModalContent maxW="600px">
          <ModalHeader>Add New Patient</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Patient ID</FormLabel>
                <Input
                  placeholder="Patient ID"
                  name="id"
                 
                  onChange={handleInputChange}
                />
              </Box>
              <Box flex="1">
                <FormLabel>Profile Photo</FormLabel>
                <Input
                  type="file"
                  name="profilePhoto"
                  onChange={handleFileChange}
                />
              </Box>
            </Flex>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Name</FormLabel>
                <Input
                  placeholder="Name"
                  name="name"
                  
                  onChange={handleInputChange}
                />
              </Box>
              <Box flex="1">
                <FormLabel>Age</FormLabel>
                <Input
                  placeholder="Age"
                  name="age"
                 
                  onChange={handleInputChange}
                />
              </Box>
            </Flex>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Gender</FormLabel>
                <Select
                  placeholder="Select gender"
                  name="gender"
                  value={newPatientData.gender}
                  onChange={handleInputChange}
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </Select>
              </Box>
              <Box flex="1">
                <FormLabel>Email</FormLabel>
                <Input
                  placeholder="Email"
                  name="email"
                  type="email"
                  value={newPatientData.email}
                  onChange={handleInputChange}
                />
              </Box>
            </Flex>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Phone Number</FormLabel>
                <Input
                  placeholder="Phone Number"
                  name="phoneNumber"
                  type="tel"
                  value={newPatientData.number}
                  onChange={handleInputChange}
                />
              </Box>
              <Box flex="1">
                <FormLabel>Lab Test</FormLabel>
                <Input
                  placeholder="Test"
                  name="test"
                  value={newPatientData.test}
                  onChange={handleInputChange}
                />
              </Box>
            </Flex>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Date</FormLabel>
                <Input
                  type="date"
                  name="date"
                  value={newPatientData.dob}
                  onChange={handleInputChange}
                />
              </Box>
            </Flex>
            <FormLabel>Past Appointments</FormLabel>
            <Textarea
              placeholder="Past Appointments"
              name="pastAppointments"
              value={newPatientData.pastAppointments}
              onChange={handleInputChange}
              width="100%"
              mb={4}
            />
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={handleAddPatient}>
              Add
            </Button>
            <Button variant="ghost" onClick={onFormClose}>
              Cancel
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
}
