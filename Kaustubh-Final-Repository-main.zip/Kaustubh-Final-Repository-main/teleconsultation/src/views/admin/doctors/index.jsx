
import React, { useState, useEffect } from "react";
import {
  Avatar,
  Box,
  Flex,
  FormLabel,
  Icon,
  Input,
  Select,
  SimpleGrid,
  useColorModeValue,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
  Textarea,
  Text,
  Badge,
  IconButton,
} from "@chakra-ui/react";
import CountUp from 'react-countup';
import { MdAddTask, MdAttachMoney, MdBarChart, MdFileCopy, MdSettings, MdAccountCircle } from "react-icons/md";
import axiosInstance from "../axios/axiosInstance";
import ComplexTable from "views/admin/default/components/ComplexTable";
import { columnsDataComplex, doctorcolumnsDataComplex } from "views/admin/default/variables/columnsData";
import { useHistory } from "react-router-dom";
import PatientDetails from "./PatientDetails"; // Import the PatientDetails component

export default function UserReports() {
  const brandColor = useColorModeValue("brand.500", "white");
  const boxBg = useColorModeValue("secondaryGray.300", "whiteAlpha.100");

  const { isOpen, onOpen, onClose } = useDisclosure();
  const { isOpen: isFormOpen, onOpen: onFormOpen, onClose: onFormClose } = useDisclosure();
  const [selectedLabTest, setSelectedLabTest] = useState(null);
  const [patientsData, setPatientsData] = useState([]);
  const [newPatientData, setNewPatientData] = useState({
    id: "",
    profilePhoto: null,
    name: "",
    age: "",
    gender: "",
    email: "",
    phoneNumber: "",
    test: "",
    date: "",
    result: "",
    pastAppointments: "",
  });

  const [showAppointmentsBar, setShowAppointmentsBar] = useState(false);
  const history = useHistory();

  useEffect(() => {
    const fetchPatientsData = async () => {
      try {
        const response = await axiosInstance.get("http://localhost:8080/api/patient/getPatients");
        setPatientsData(response.data.data);
      } catch (error) {
        console.error("Error fetching patients data:", error);
      }
    };

    fetchPatientsData();
  }, []);

  const handleLabTestClick = (labTest) => {
    setSelectedLabTest(labTest);
    onOpen();
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewPatientData({ ...newPatientData, [name]: value });
  };

  const handleFileChange = (e) => {
    setNewPatientData({ ...newPatientData, profilePhoto: e.target.files[0] });
  };

  const handleAddPatient = async () => {
    try {
      const formData = new FormData();
      formData.append("id", newPatientData.id);
      if (newPatientData.profilePhoto) {
        formData.append("profilePhoto", newPatientData.profilePhoto);
      }
      formData.append("name", newPatientData.name);
      formData.append("age", newPatientData.age);
      formData.append("gender", newPatientData.gender);
      formData.append("email", newPatientData.email);
      formData.append("number", newPatientData.phoneNumber);
      formData.append("test", newPatientData.test);
      formData.append("date", newPatientData.date);
      formData.append("result", newPatientData.result);
      formData.append("pastAppointments", newPatientData.pastAppointments);

      await axiosInstance.post("http://localhost:8080/api/patient/AddPatient", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      const response = await axiosInstance.get("http://localhost:8080/api/patient/getPatients");
      setPatientsData(response.data.data);
      onFormClose();
    } catch (error) {
      console.error("Error adding new patient:", error);
    }
  };

  const handleAppointmentsClick = () => {
    setShowAppointmentsBar(true);
  };

  const handleRowClick = (patient) => {
    setSelectedPatient(patient)
  };

  const tableDataComplex = [
    {
      patient_id: "P001",
      token_no: "001",
      name: "John Doe",
      age: 45,
      gender: "Male",
      past_appointments: "10 Jan 2023",
      status: "Ongoing",
      service_name: "Checkup",
      date: "2024-06-15",
      doctor: "Dr. Smith",
      treatment_type: "Checkup",
      booking_time: "10:00 AM",
      comments: "No Comments",
      payment_action: "Paid",
      created_date: "11/02/23",
      service_type: "imaging",
      total_amount: "12200",
    },
    {
      patient_id: "P002",
      token_no: "002",
      name: "Jane Smith",
      age: 37,
      gender: "Female",
      past_appointments: "20 Feb 2023",
      status: "Booked",
      service_name: "Dental",
      date: "2024-06-20",
      doctor: "Dr. Johnson",
      treatment_type: "Dental",
      booking_time: "11:30 AM",
      comments: "No Comments",
      payment_action: "Pending",
      created_date: "11/02/23",
      service_type: "imaging",
      total_amount: "12200",
    },
    {
      patient_id: "P003",
      token_no: "003",
      name: "Robert Brown",
      age: 50,
      gender: "Male",
      past_appointments: "05 Mar 2023",
      status: "Reviewed",
      service_name: "MRI",
      date: "2024-06-25",
      doctor: "Dr. White",
      treatment_type: "MRI",
      booking_time: "02:00 PM",
      comments: "No Comments",
      payment_action: "Paid",
      created_date: "14/02/23",
      service_type: "imaging",
      total_amount: "12200",
    },
    {
      patient_id: "P004",
      token_no: "004",
      name: "Emily Davis",
      age: 29,
      gender: "Female",
      past_appointments: "15 Apr 2023",
      status: "Booked",
      service_name: "Blood Test",
      date: "2024-06-30",
      doctor: "Dr. Black",
      treatment_type: "Blood Test",
      booking_time: "09:00 AM",
      comments: "No Comments",
      payment_action: "Pending",
      created_date: "11/03/13",
      service_type: "imaging",
      total_amount: "12200",
    },
    {
      patient_id: "P005",
      token_no: "005",
      name: "Robert Brown",
      age: 50,
      gender: "Male",
      past_appointments: "05 Mar 2023",
      status: "Reviewed",
      service_name: "Checkup",
      date: "2024-06-15",
      doctor: "Dr. Smith",
      treatment_type: "Checkup",
      booking_time: "10:00 AM",
      comments: "No Comments",
      service_type: "imaging",
      total_amount: "32200",
    },
    {
      patient_id: "P006",
      token_no: "006",
      name: "Emily Davis",
      age: 29,
      gender: "Female",
      past_appointments: "15 Apr 2023",
      status: "Ongoing",
      service_name: "Checkup",
      date: "2024-06-15",
      doctor: "Dr. Smith",
      treatment_type: "Checkup",
      booking_time: "10:00 AM",
      comments: "No Comments",
      payment_action: "Paid",
      service_type: "imaging",
      total_amount: "232200",
    },
    {
      patient_id: "P007",
      token_no: "007",
      name: "Robert Brown",
      age: 50,
      gender: "Male",
      past_appointments: "05 Mar 2023",
      status: "Booked",
      service_name: "Checkup",
      date: "2024-06-15",
      doctor: "Dr. Smith",
      treatment_type: "Checkup",
      booking_time: "10:00 AM",
      comments: "No Comments",
      payment_action: "Paid",
    },
    {
      patient_id: "P008",
      token_no: "008",
      name: "Emily Davis",
      age: 29,
      gender: "Female",
      past_appointments: "15 Apr 2023",
      status: "Arrived",
      service_name: "Checkup",
      date: "2024-06-15",
      doctor: "Dr. Smith",
      treatment_type: "Checkup",
      booking_time: "10:00 AM",
      comments: "No Comments",
      payment_action: "Paid",
    },
  ];
  const [selectedPatient, setSelectedPatient] = useState(null); // State to hold selected patient data


  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }} w="100%" overflowX="auto">
    <>
      <Flex mb="10px" justifyContent="space-between">
        <Button variant="outline" colorScheme="blue" onClick={handleAppointmentsClick}>
          Appointments
        </Button>
        <Button variant="outline" colorScheme="green">
          Consultations
        </Button>
        <Button variant="outline" colorScheme="purple">
          Teleconsultation
        </Button>
        <Button variant="outline" colorScheme="red">
          Refer
        </Button>
        <Button variant="outline" colorScheme="pink">
          New Patients
        </Button>
        <Flex>
          <IconButton
            icon={<MdAccountCircle />}
            variant="outline"
            colorScheme="gray"
            aria-label="Account"
            mr="4"
          />
          <IconButton
            icon={<MdSettings />}
            variant="outline"
            colorScheme="gray"
            aria-label="Settings"
          />
        </Flex>
      </Flex>
      
      <>
        <Flex mb="20px" justifyContent="space-between" bg={boxBg} p="10px" borderRadius="md">
          <Text fontWeight="bold">Date: <Text as="span" fontSize="xl" color="blue.500" fontWeight="bold">2023-06-05</Text></Text>
          <Text fontWeight="bold">Total Appointments: <Text as="span" fontSize="xl" color="teal.500" fontWeight="bold"><CountUp start={0} end={50} duration={1} /></Text></Text>
          <Text fontWeight="bold">Pending Appointments: <Text as="span" fontSize="xl" color="red.500" fontWeight="bold"><CountUp start={0} end={5} duration={1} /></Text></Text>
          <Text fontWeight="bold">Completed Appointments: <Text as="span" fontSize="xl" color="green.500" fontWeight="bold"><CountUp start={0} end={40} duration={1} /></Text></Text>
        </Flex>
        
        <SimpleGrid columns={1} gap="20px" mb="20px">
          {selectedPatient ? (
            <Box mt="-70px">
            <PatientDetails location={{ state: { patient: selectedPatient } }} /></Box>
          ) : (
            <ComplexTable
              columnsData={doctorcolumnsDataComplex}
              tableData={tableDataComplex}
              onRowClick={handleRowClick}
            />
          )}
        </SimpleGrid>
        
      </>
    </>
  </Box>
  
  );
}
