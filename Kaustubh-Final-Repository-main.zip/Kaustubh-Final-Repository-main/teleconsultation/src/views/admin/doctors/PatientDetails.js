import React,{useState} from "react";
import {
  Avatar,
  Box,
  Flex,
  Text,
  Button,
  IconButton,
  Input,
  Modal,
  ModalOverlay,ModalBody,ModalContent,ModalHeader,ModalCloseButton,ModalFooter,
  Textarea,
  Select,
  useColorModeValue,
} from "@chakra-ui/react";
import { MdVideoCall, MdPrint, MdSave, MdEmail, MdExitToApp, MdWifi,MdWhatsapp } from "react-icons/md";
import { useHistory } from "react-router-dom";

const PatientDetails = ({ location }) => {
  const { patient } = location.state;
  const history = useHistory();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [paymentMode, setPaymentMode] = useState("");
  const [consultationType, setConsultationType] = useState({
    firstConsultation: false,
    followUp: false,
  });

  const handleConsultationTypeChange = (type) => {
    setConsultationType((prev) => ({
      ...prev,
      [type]: !prev[type],
    }));
  };

  const handleOnlineConsultation = () => {
    // Logic for online consultation
    console.log("Online consultation requested");
  };

  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }} w="100%" overflowX="auto">
      <Button variant="outline" colorScheme="blue" onClick={() => history.goBack()}>
        Back
      </Button>
      <Flex alignItems="center" justifyContent="center" mt="20px">
        <Avatar size="2xl" src={patient.profile_photo} mr="20px" />
        <Box>
          <Text fontWeight="bold" fontSize="2xl" mb="1">{patient.name}</Text>
          <Text color="gray.600">{patient.gender}, {patient.age} years old</Text>
          <Text color="gray.600"><b>Phone No:</b> {patient.phone_no}</Text>
        </Box>
        <IconButton
          icon={<MdVideoCall />}
          variant="outline"
          colorScheme="blue"
          aria-label="Video Call"
          fontSize="42px"
          ml="50px"
          onClick={() => setIsModalOpen(true)}
        />
      </Flex>
      <table style={{ width: "100%", marginTop: "10px", borderCollapse: "collapse"}}>
        <tbody>
          <tr>
            <td colSpan="2" style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Button variant="outline" colorScheme="blue" mx="2">1st Visit</Button>
              <Button variant="outline" colorScheme="blue" mx="2">View Past Visits</Button>
              <Button variant="outline" colorScheme="blue" mx="2">Load Template</Button>
              <Button variant="outline" colorScheme="blue" mx="2">Save as Template</Button>
              <Button variant="outline" colorScheme="blue" mx="2">Clear All</Button>
            </td>
          </tr>
          <tr>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Text fontWeight="bold">Vitals:</Text>
            </td>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <table width="100%" style={{ borderCollapse: "collapse"}}>
                <thead>
                  <tr>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>BP</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Pulse</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Weight</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>SpO2</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Height</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Temperature</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>120/80</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>72 bpm</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>70 kg</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>98%</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>175 cm</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>98.6°F</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Text fontWeight="bold">Allergies:</Text>
            </td>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <table width="100%" style={{ borderCollapse: "collapse"}}>
                <thead>
                  <tr>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Medicines</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Food</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Other</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Penicillin</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Peanuts</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Pollen</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Text fontWeight="bold">Complaints:</Text>
            </td>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <table width="100%" style={{ borderCollapse: "collapse"}}>
                <thead>
                  <tr>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>No.</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Complaint</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Frequency</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Severity</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Duration</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>1</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Headache</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Daily</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Moderate</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>2 weeks</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>2024-06-06</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Text fontWeight="bold">Diagnosis:</Text>
            </td>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <table width="100%" style={{ borderCollapse: "collapse"}}>
                <thead>
                  <tr>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Serial No.</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Diagnosis</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Duration</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>1</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Migraine</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>2 weeks</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>2024-06-06</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Text fontWeight="bold">Medicines:</Text>
            </td>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <table width="100%" style={{ borderCollapse: "collapse"}}>
                <thead>
                  <tr>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Type</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Dosage</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>When</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Frequency</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Duration</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>From-To</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Tablet</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>500mg</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Morning</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Twice a day</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>1 week</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>2024-06-01 to 2024-06-07</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Text fontWeight="bold">Advice:</Text>
            </td>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Text>Drink plenty of water</Text>
              <Text>Take regular breaks</Text>
              <Text>Avoid stress</Text>
            </td>
          </tr>
          <tr>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <Text fontWeight="bold">Test Required:</Text>
            </td>
            <td style={{ border: "1px solid #E2E8F0", padding: "10px", background: "#EDF2F7", textAlign: "center" }}>
              <table width="100%" style={{ borderCollapse: "collapse"}}>
                <thead>
                  <tr>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Serial No.</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Test Name</th>
                    <th style={{ border: "1px solid #E2E8F0", padding: "5px" }}>By When</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>1</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>Blood Test</td>
                    <td style={{ border: "1px solid #E2E8F0", padding: "5px" }}>2024-06-10</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
      <Box mt="20px" p="10px" border="1px solid #E2E8F0" background="#EDF2F7">
        <Text fontWeight="bold" mb="10px">Next Visit:</Text>
        <Flex mb="10px">
          <Input placeholder="Enter next visit date" type="date" mr="10px" />
        
        </Flex>
        <Text fontWeight="bold" mb="10px">Referred To:</Text>
        <Flex direction="row" mb="10px">
          <Input placeholder="Doctor Name" mb="5px" />
          <Input placeholder="Speciality" mb="5px" />
          <Input placeholder="Phone" mb="5px" />
          <Input placeholder="Email" />
        </Flex>
        <Text fontWeight="bold" mb="10px">Investigation:</Text>
        <Flex mb="10px">
          <Input placeholder="Investigation Details" />
          <Button colorScheme="blue" ml="10px">Add</Button>
        </Flex>
        <Text fontWeight="bold">Past Medication:</Text>
        <Textarea placeholder="Enter past medication details" />
      </Box>

      <Box position="fixed" bottom="0" left="0" right="0" p="10px" bg="gray.100" borderTop="1px solid #E2E8F0" zIndex="1000">
        <Flex justifyContent="space-between" alignItems="center">
          <Flex alignItems="center">
            <IconButton
              icon={<MdWifi />}
              aria-label="WiFi"
              fontSize="24px"
              mr="2"
              variant="ghost"
            />
            <Text>3 MB/s</Text>
          </Flex>
          <Text color="green.500">Synched 40%</Text>
          <Select placeholder="Preferred Language" w="150px" mr="10px">
            <option value="english">English</option>
            <option value="spanish">Spanish</option>
            <option value="french">French</option>
          </Select>
          <Flex>
          <IconButton
              icon={<MdWhatsapp/>}
              colorScheme="teal"
              aria-label="Email"
              fontSize="24px"
              mr="2"
            />
            <IconButton
              icon={<MdEmail />}
              colorScheme="teal"
              aria-label="Email"
              fontSize="24px"
              mr="2"
            />
            <IconButton
              icon={<MdPrint />}
              colorScheme="blue"
              aria-label="Print"
              fontSize="24px"
              mr="2"
            />
            <IconButton
              icon={<MdSave />}
              colorScheme="green"
              aria-label="Save"
              fontSize="24px"
              mr="2"
            />
            <IconButton
              icon={<MdExitToApp />}
              colorScheme="red"
              aria-label="End Consultation"
              fontSize="24px"
              mr="2"
            />
          </Flex>
        </Flex>
      </Box>
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Online Consultation</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Box>
              <Text mb="1">Consultation Type:</Text>
              <Flex alignItems="center" mb="4">
                <input
                  type="checkbox"
                  id="firstConsultation"
                  checked={consultationType.firstConsultation}
                  onChange={() => handleConsultationTypeChange("firstConsultation")}
                  style={{ marginRight: "5px" }}
                />
                <label htmlFor="firstConsultation">First Consultation</label>
              </Flex>
              <Flex alignItems="center" mb="4">
                <input
                  type="checkbox"
                  id="followUp"
                  checked={consultationType.followUp}
                  onChange={() => handleConsultationTypeChange("followUp")}
                  style={{ marginRight: "5px" }}
                />
                <label htmlFor="followUp">Follow-Up</label>
              </Flex>
              <Box mb="4">
                <Text>Amount:</Text>
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </Box>
              <Box mb="4">
                <Text>Payment Mode:</Text>
                <Select
                  placeholder="Select payment mode"
                  value={paymentMode}
                  onChange={(e) => setPaymentMode(e.target.value)}
                >
                  <option value="creditCard">Credit Card</option>
                  <option value="debitCard">Debit Card</option>
                  <option value="paypal">PayPal</option>
                </Select>
              </Box>
            </Box>
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" onClick={handleOnlineConsultation}>
              Online Consultation
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
};

export default PatientDetails;
