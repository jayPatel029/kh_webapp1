export const columnsDataCheck = [
  {
    Header: "PATIENT ID",
    accessor: "id",
  },
  {
    Header: "PROFILE PHOTO",
    accessor: "profile_photo",
  },
  {
    Header: "NAME",
    accessor: "name",
  },
  {
    Header: "GENDER",
    accessor: "gender",
  },
  {
    Header: "AGE",
    accessor: "age",
  },
  {
    Header: "EMAIL",
    accessor: "email",
  },
  {
    Header: "PHONE NO",
    accessor: "number",
  },
  {
    Header: "PAST APPOINMENTS",
    accessor: "past_appointments",
  },
  {
    Header: "LAB TESTS",
    accessor: "lab_tests",
  },
  {
    Header: "BOOK APPOINMENTS",
    accessor: "book_appointments",
  },
];

export const columnsDataComplex = [
  {
    Header: "PATIENT ID",
    accessor: "id",
  },
  {
    Header: "PROFILE PHOTO",
    accessor: "profile_photo",
  },
  {
    Header: "NAME",
    accessor: "name",
  },
  {
    Header: "GENDER",
    accessor: "gender",
  },
  {
    Header: "AGE",
    accessor: "age",
  },
  {
    Header: "EMAIL",
    accessor: "email",
  },
  {
    Header: "PHONE NO",
    accessor: "number",
  },
  {
    Header: "PAST APPOINTMENTS",
    accessor: "past_appointments",
  },
  {
    Header: "LAB TESTS",
    accessor: "lab_tests",
  },
  {
    Header: "BOOK APPOINTMENTS",
    accessor: "book_appointments",
  },
];

export const appointmentcolumnsDataComplex = [
  {
    Header: "APPOINTMENT ID",
    accessor: "appointment_id",
  },
  {
    Header: "DATE",
    accessor: "date",
  },
  {
    Header: "PATIENT",
    accessor: "name",
  },
  {
    Header: "DOCTOR",
    accessor: "doctor",
  },
  {
    Header: "TREATMENT TYPE",
    accessor: "treatment_type",
  },
  {
    Header: "BOOKING TIME",
    accessor: "booking_time",
  },
  {
    Header: "COMMENTS",
    accessor: "comments",
  },
  {
    Header: "PAYMENT ACTION",
    accessor: "payment_action",
  },
];

export const doctorcolumnsDataComplex = [
  {
    Header: "PATIENT ID",
    accessor: "patient_id",
  },
  {
    Header: "TOKEN NO",
    accessor: "token_no",
  },
  {
    Header: "PATIENT NAME",
    accessor: "name",
  },
  {
    Header: "AGE",
    accessor: "age",
  },
  {
    Header: "SEX",
    accessor: "gender",
  },
  {
    Header: "PAST VISIT",
    accessor: "past_appointments",
  },
  {
    Header: "STATUS",
    accessor: "status",
  },
  {
    Header: "SERVICE",
    accessor: "service_name",
  },
];



  export const billscolumnsDataComplex = [
   
    {
      Header: "Created Date",
      accessor: "created_date", // Replace with the actual accessor for created date
    },
    {
      Header: "Service Type",
      accessor: "service_type", // Replace with the actual accessor for service type
    },
    {
      Header: "Service Name",
      accessor: "service_name", // Replace with the actual accessor for service name
    },
    {
      Header: "Total Amount",
      accessor: "total_amount", // Replace with the actual accessor for total amount
    },
  ];
  