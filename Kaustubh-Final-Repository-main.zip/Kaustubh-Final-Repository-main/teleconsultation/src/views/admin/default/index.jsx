/*!
  _   _  ___  ____  ___ ________  _   _   _   _ ___   
 | | | |/ _ \|  _ \|_ _|__  / _ \| \ | | | | | |_ _| 
 | |_| | | | | |_) || |  / / | | |  \| | | | | || | 
 |  _  | |_| |  _ < | | / /| |_| | |\  | | |_| || |
 |_| |_|\___/|_| \_\___/____\___/|_| \_|  \___/|___|
                                                                                                                                                                                                                                                                                                                                       
=========================================================
* Horizon UI - v1.1.0
=========================================================

* Product Page: https://www.horizon-ui.com/
* Copyright 2023 Horizon UI (https://www.horizon-ui.com/)

* Designed and Coded by Simmmple

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/

// Chakra imports
import {
  Box,
  Icon,
  SimpleGrid,
  useColorModeValue,
  Text
} from "@chakra-ui/react";
// Assets
// Custom components
import MiniCalendar from "components/calendar/MiniCalendar";
import MiniStatistics from "components/card/MiniStatistics";
import IconBox from "components/icons/IconBox";
import React from "react";
import {
  MdBarChart,
  MdCheckCircle,
  MdPending,
  MdCancel,
} from "react-icons/md";
import CheckTable from "views/admin/default/components/CheckTable";
import ComplexTable from "views/admin/default/components/ComplexTable";
import DailyTraffic from "views/admin/default/components/DailyTraffic";
import PieCard from "views/admin/default/components/PieCard";
import Tasks from "views/admin/default/components/Tasks";
import TotalSpent from "views/admin/default/components/TotalSpent";
import WeeklyRevenue from "views/admin/default/components/WeeklyRevenue";
import {
  columnsDataCheck,
  columnsDataComplex,
} from "views/admin/default/variables/columnsData";
import tableDataCheck from "views/admin/default/variables/tableDataCheck.json";
import tableDataComplex from "views/admin/default/variables/tableDataComplex.json";



export default function UserReports() {
  // Chakra Color Mode
  const brandColor = useColorModeValue("brand.500", "white");
  const boxBg = useColorModeValue("secondaryGray.300", "whiteAlpha.100");
  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <SimpleGrid columns={{ base: 1, md: 2, lg: 2 }} gap='20px' mb='20px'>
        <Box
          p='20px'
          bg='white'
          borderRadius='md'
          boxShadow='sm'
          display='flex'
          flexDirection='column'
          flex={1}
        >
          <Text fontSize='2xl' fontWeight='bold' mb='20px'>
            Appointment Overview
          </Text>
          <div className="flex">
            <MiniStatistics
              name='Total Appointments'
              value='1,200'
              textColor="#013220"
            />
            <MiniStatistics
              name='Confirmed'
              value='850'
              textColor="#1fd655"
            />
            <MiniStatistics
              name='Pending'
              value='250'
              textColor="#fdd017"
            />
            <MiniStatistics
              name='Rejected'
              value='100'
              textColor="red"
            />
          </div>
        </Box>
        <Box
          p='20px'
          bg='white'
          borderRadius='md'
          boxShadow='sm'
          display='flex'
          flexDirection='column'
        >
          <Text fontSize='2xl' fontWeight='bold' mb='20px'>
            Payment Overview
          </Text>
          <div className="flex">
            <MiniStatistics
              name='Payments Accepted'
              value='500'
              textColor="#1fd655"
            />
            <MiniStatistics
              name='Payments Pending'
              value='100'
              textColor="#fdd017"
            />
            <MiniStatistics
              name='Payments Rejected'
              value='10'
              textColor="red"
            />
          </div>
        </Box>
      </SimpleGrid>



      <SimpleGrid columns={{ base: 1, md: 2, xl: 2 }} gap='20px' mb='20px'>
        <TotalSpent />
        <WeeklyRevenue />
      </SimpleGrid>
      <SimpleGrid columns={{ base: 1, md: 1, xl: 2 }} gap='20px' mb='20px'>
        <CheckTable columnsData={columnsDataCheck} tableData={tableDataCheck} />
        <SimpleGrid columns={{ base: 1, md: 2, xl: 2 }} gap='20px'>
          <DailyTraffic />
          <PieCard />
        </SimpleGrid>
      </SimpleGrid>
      <SimpleGrid columns={{ base: 1, md: 1, xl: 2 }} gap='20px' mb='20px'>
        <ComplexTable
          columnsData={columnsDataComplex}
          tableData={tableDataComplex}
        />
        <SimpleGrid columns={{ base: 1, md: 2, xl: 2 }} gap='20px'>
          <Tasks />

        </SimpleGrid>
      </SimpleGrid>
    </Box>
  );
}
