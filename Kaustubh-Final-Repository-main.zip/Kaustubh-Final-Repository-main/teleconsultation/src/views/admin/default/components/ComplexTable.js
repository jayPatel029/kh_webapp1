import React, { useState, useMemo, useCallback } from "react";
import {
  Box,
  Button,
  Flex,
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
  useColorModeValue,
  Avatar,
  Stack,
  FormLabel,
  Select,
  Input,
  InputGroup,
} from "@chakra-ui/react";
import { useTable, useGlobalFilter, useSortBy, usePagination } from "react-table";
import Card from "../../../../components/card/Card";
import BookAppointmentModal from "./BookAppointmentModal";
import LabTestsModal from "./UserLabreports/LabTestsModal";

export default function ComplexTable({ columnsData, tableData, onRowClick, isAppointment = false }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLabOpen, setIsLabOpen] = useState(false);
  const [selectedData, setSelectedData] = useState(null);
  const [billingSummary, setBillingSummary] = useState(null);
  const [filters, setFilters] = useState({
    doctor: "",
    paymentStatus: "",
    appointmentDate: "",
  });
  const [newAppointmentData, setNewAppointmentData] = useState({
    patient: "",
    doctor: "",
    date: "",
    time: "",
    notes: "",
    vitals: {
      height: "",
      weight: "",
      temperature: "",
      bloodPressure: "",
      sugarLevel: "",
      respirationRate: "",
      pulseRate: "",
    },
    bill: 0,
  });

  const openModal = () => setIsOpen(true);
  const closeModal = () => setIsOpen(false);
  const openLabModal = () => setIsLabOpen(true);
  const closeLabModal = () => setIsLabOpen(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewAppointmentData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleVitalsChange = (e) => {
    const { name, value } = e.target;
    setNewAppointmentData((prevData) => ({
      ...prevData,
      vitals: { ...prevData.vitals, [name]: value },
    }));
  };

  const handleGenerateBill = () => {
    const subtotal = 56.00;
    const discount = 28.00;
    const total = subtotal - discount;

    setBillingSummary({
      subtotal,
      discountCode: "STUDENT",
      discountAmount: discount,
      discountPercentage: 50,
      total,
    });
  };

  const handleBookAppointment = () => {
    closeModal();
  };

  const handlePastAppointmentsClick = (data) => {
    alert("Past appointments for " + data.name);
  };

  const handleLabTestsClick = (data) => {
    setSelectedData(data);
    openLabModal();
  };

  const handleCommentsClick = (comments) => {
    alert(comments);
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prevFilters) => ({
      ...prevFilters,
      [name]: value,
    }));
  };

  const filteredData = useMemo(() => {
    return tableData.filter((row) => {
      return (
        (filters.doctor === "" || row.doctor === filters.doctor) &&
        (filters.paymentStatus === "" || row.paymentStatus === filters.paymentStatus) &&
        (filters.appointmentDate === "" || row.date === filters.appointmentDate)
      );
    });
  }, [filters, tableData]);

  const columns = useMemo(() => columnsData, [columnsData]);
  const data = useMemo(() => filteredData, [filteredData]);

  const patients = [
    { id: "1", name: "John Doe" },
    { id: "2", name: "Jane Smith" },
  ];

  const doctors = [
    { id: "1", name: "Dr. Smith" },
    { id: "2", name: "Dr. Black" },
  ];

  const services = [
    { id: "1", name: "First Consultation", price: 100 },
    { id: "2", name: "Follow up Consultation", price: 80 },
    { id: "3", name: "2D echo", price: 150 },
    { id: "4", name: "Biopsy", price: 200 },
    { id: "5", name: "ECG", price: 50 },
    { id: "6", name: "Ultrasound", price: 120 },
    { id: "7", name: "Blood Test", price: 30 },
  ];

  const tableInstance = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0, pageSize: 4 },
    },
    useGlobalFilter,
    useSortBy,
    usePagination
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize },
  } = tableInstance;

  const textColor = useColorModeValue("secondaryGray.900", "white");
  const borderColor = useColorModeValue("gray.200", "whiteAlpha.100");

  const handleBookAppointmentClick = (data) => {
    setSelectedData(data);
    openModal();
  };

  return (
    <Card direction="column" w="100%" px="0px">
      {isAppointment && (
        <Stack direction={{ base: "column", md: "row" }} spacing="20px" mb="20px" ml="40px">
          <Flex align="center">
            <FormLabel htmlFor="doctor">Doctor:</FormLabel>
            <Select
              id="doctor"
              name="doctor"
              onChange={handleFilterChange}
              placeholder="Select Doctor"
            >
              {doctors.map((doctor) => (
                <option key={doctor.id} value={doctor.name}>
                  {doctor.name}
                </option>
              ))}
            </Select>
          </Flex>
          <Flex align="center">
            <FormLabel htmlFor="paymentStatus">Payment Status:</FormLabel>
            <Select
              id="paymentStatus"
              name="paymentStatus"
              onChange={handleFilterChange}
              placeholder="Select Payment Status"
            >
              <option value="paid">Paid</option>
              <option value="pending">Pending</option>
            </Select>
          </Flex>
          <Flex align="center">
            <FormLabel htmlFor="appointmentDate">Date:</FormLabel>
            <InputGroup>
              <Input
                type="date"
                id="appointmentDate"
                name="appointmentDate"
                onChange={handleFilterChange}
              />
            </InputGroup>
          </Flex>
        </Stack>
      )}
      <Flex px="25px" justify="space-between" mb="10px" align="center">
        <Box overflowX="auto">
          <Table {...getTableProps()} variant="simple" color="gray.500" mb="24px">
            <Thead>
              {headerGroups.map((headerGroup, index) => (
                <Tr {...headerGroup.getHeaderGroupProps()} key={index}>
                  {headerGroup.headers.map((column, index) => (
                    <Th
                      {...column.getHeaderProps(column.getSortByToggleProps())}
                      pe="10px"
                      key={index}
                      borderColor={borderColor}
                      width="150px"
                    >
                      <Flex
                        justify="space-between"
                        align="center"
                        fontSize={{ sm: "10px", lg: "12px" }}
                        color="gray.400"
                      >
                        {column.render("Header")}
                      </Flex>
                    </Th>
                  ))}
                </Tr>
              ))}
            </Thead>
            <Tbody {...getTableBodyProps()}>
              {page.map((row, index) => {
                prepareRow(row);
                return (
                  <Tr
                    {...row.getRowProps()}
                    key={index}
                    onClick={() => onRowClick(row.original)}
                    style={{ cursor: "pointer" }}
                  >
                    {row.cells.map((cell, index) => {
                      let data = "";
                      if (cell.column.Header === "TOKEN NO") {
                        data = cell.render("Cell");
                      } else if (cell.column.Header === "BOOK APPOINTMENTS") {
                        data = (
                          <Button
                            colorScheme="teal"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleBookAppointmentClick(cell.row.original);
                            }}
                          >
                            Book Appointment
                          </Button>
                        );
                      } else if (cell.column.Header === "PROFILE PHOTO") {
                        data = (
                          <Avatar size="sm" name={cell.value} src={cell.value} />
                        );
                      } else if (cell.column.Header === "PAST APPOINTMENTS") {
                        data = (
                          <Button
                            colorScheme="blue"
                            onClick={(e) => {
                              e.stopPropagation();
                              handlePastAppointmentsClick(cell.row.original);
                            }}
                          >
                            View Past Appointments
                          </Button>
                        );
                      } else if (cell.column.Header === "LAB TESTS") {
                        data = (
                          <Button
                            colorScheme="purple"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleLabTestsClick(cell.row.original);
                            }}
                          >
                            View Lab Tests
                          </Button>
                        );
                      } else if (cell.column.Header === "COMMENTS") {
                        data = (
                          <Button
                            colorScheme="orange"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCommentsClick(cell.row.original.comments);
                            }}
                          >
                            View Comments
                          </Button>
                        );
                      } else {
                        data = cell.render("Cell");
                      }
                      return (
                        <Td
                          {...cell.getCellProps()}
                          key={index}
                          fontSize={{ sm: "14px" }}
                          borderColor="transparent"
                        >
                          {data}
                        </Td>
                      );
                    })}
                  </Tr>
                );
              })}
            </Tbody>
          </Table>
        </Box>
      </Flex>

      <Flex justify="space-between" align="center" px="25px">
        <Box>
          <Button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
            {"<<"}
          </Button>{" "}
          <Button onClick={previousPage} disabled={!canPreviousPage}>
            {"<"}
          </Button>{" "}
          <Button onClick={nextPage} disabled={!canNextPage}>
            {">"}
          </Button>{" "}
          <Button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
            {">>"}
          </Button>{" "}
        </Box>
        <Box>
          <span>
            Page{" "}
            <strong>
              {pageIndex + 1} of {pageOptions.length}
            </strong>{" "}
          </span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
          >
            {[4, 8, 12].map((pageSize) => (
              <option key={pageSize} value={pageSize}>
                Show {pageSize}
              </option>
            ))}
          </select>
        </Box>
      </Flex>

      <BookAppointmentModal
        isOpen={isOpen}
        onClose={closeModal}
        onChange={handleInputChange}
        onBook={handleBookAppointment}
        billingSummary={billingSummary}
        onVitalsChange={handleVitalsChange}
        onGenerateBill={handleGenerateBill}
        newAppointmentData={newAppointmentData}
        patients={patients}
        doctors={doctors}
        services={services}
      />

      {selectedData && (
        <LabTestsModal
          id={selectedData.id}
          isOpen={isLabOpen}
          onClose={closeLabModal}
          userName={selectedData.name}
        />
      )}
    </Card>
  );
}
