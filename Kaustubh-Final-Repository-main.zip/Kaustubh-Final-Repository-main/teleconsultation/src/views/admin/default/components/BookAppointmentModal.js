import React, { useState } from "react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Flex,
  FormLabel,
  Select,
  Input,
  Textarea,
  Button,
} from "@chakra-ui/react";

const BookAppointmentModal = ({
  isOpen,
  onClose,
  patients,
  doctors,
  services,
  newAppointmentData,
  setNewAppointmentData,
  handleInputChange,
  handleVitalsChange,
  handleGenerateBill,
  billingSummary, // Added billingSummary prop
}) => {
  const [isBillGenerated, setIsBillGenerated] = useState(false);

  const handleGenerateBillClick = () => {
    handleGenerateBill();
    setIsBillGenerated(true);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered motionPreset="slideInBottom" size="2xl">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Book Appointment</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <Flex mb={4} direction="row" justifyContent="space-between">
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="patientSelect">Patient</FormLabel>
              <Select
                id="patientSelect"
                placeholder="Select Patient"
                onChange={(e) =>
                  setNewAppointmentData({
                    ...newAppointmentData,
                    patientId: e.target.value,
                  })
                }
                mb={2}
              >
                {patients.map((patient) => (
                  <option key={patient.id} value={patient.id}>
                    {patient.name}
                  </option>
                ))}
              </Select>
            </Flex>
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="doctorSelect">Doctor</FormLabel>
              <Select
                id="doctorSelect"
                placeholder="Select Doctor"
                onChange={(e) =>
                  setNewAppointmentData({
                    ...newAppointmentData,
                    doctorId: e.target.value,
                  })
                }
                mb={2}
              >
                {doctors.map((doctor) => (
                  <option key={doctor.id} value={doctor.id}>
                    {doctor.name}
                  </option>
                ))}
              </Select>
            </Flex>
          </Flex>
          <Flex mb={4} direction="row" justifyContent="space-between">
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="serviceSelect">Service</FormLabel>
              <Select
                id="serviceSelect"
                placeholder="Select Service"
                onChange={(e) =>
                  setNewAppointmentData({
                    ...newAppointmentData,
                    serviceId: e.target.value,
                  })
                }
                mb={2}
              >
                {services.map((service) => (
                  <option key={service.id} value={service.id}>
                    {service.name}
                  </option>
                ))}
              </Select>
            </Flex>
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="appointmentDate">Appointment Date</FormLabel>
              <Input
                type="date"
                id="appointmentDate"
                name="appointmentDate"
                placeholder="Appointment Date"
                value={newAppointmentData.appointmentDate}
                onChange={handleInputChange}
                mb={2}
              />
            </Flex>
          </Flex>
          <Flex mb={4} direction="row" justifyContent="space-between">
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="appointmentTime">Appointment Time</FormLabel>
              <Input
                type="time"
                id="appointmentTime"
                name="appointmentTime"
                placeholder="Appointment Time"
                value={newAppointmentData.appointmentTime}
                onChange={handleInputChange}
                mb={2}
              />
            </Flex>
          
          </Flex>
          <Flex mb={4} direction="row" justifyContent="space-between">
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="bp">Blood Pressure</FormLabel>
              <Input
                type="text"
                id="bp"
                name="bp"
                placeholder="Blood Pressure"
                value={newAppointmentData.vitals.bp}
                onChange={handleVitalsChange}
                mb={2}
              />
            </Flex>
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="spo2">SpO2</FormLabel>
              <Input
                type="text"
                id="spo2"
                name="spo2"
                placeholder="SpO2"
                value={newAppointmentData.vitals.spo2}
                onChange={handleVitalsChange}
                mb={2}
              />
            </Flex>
          </Flex>
          <Flex mb={4} direction="row" justifyContent="space-between">
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="height">Height</FormLabel>
              <Input
                type="text"
                id="height"
                name="height"
                placeholder="Height"
                value={newAppointmentData.vitals.height}
                onChange={handleVitalsChange}
                mb={2}
              />
            </Flex>
            <Flex direction="column" width="48%">
              <FormLabel htmlFor="weight">Weight</FormLabel>
              <Input
                type="text"
                id="weight"
                name="weight"
                placeholder="Weight"
                value={newAppointmentData.vitals.weight}
                onChange={handleVitalsChange}
                mb={2}
              />
            </Flex>
          </Flex>
        </ModalBody>
        <ModalFooter>
          <Button colorScheme="blue" onClick={handleGenerateBillClick}>
            Generate Bill
          </Button>
        </ModalFooter>

        {/* Summary Section */}
        {isBillGenerated && billingSummary && (
          <Flex direction="column" p={6} bg="gray.50" w="100%">
            <h3 className="text-xl font-semibold leading-5 text-gray-800 mb={6}">Summary</h3>
            <Flex justifyContent="space-between" mb={4}>
              <p className="text-base leading-4 text-gray-800">Subtotal</p>
              <p className="text-base leading-4 text-gray-600">${billingSummary.subtotal}</p>
            </Flex>
            <Flex justifyContent="space-between" mb={2}>
              <p className="text-base leading-4 text-gray-800">
                Discount
               
              </p>
              <p className="text-base leading-4 text-gray-600">
                -${billingSummary.discountAmount} ({billingSummary.discountPercentage}%)
              </p>
            </Flex>
            <Flex justifyContent="space-between" mt={4}>
              <p className="text-base font-semibold leading-4 text-gray-800">Total</p>
              <p className="text-base font-semibold leading-4 text-gray-600">
                ${billingSummary.total}
              </p>
            </Flex>
            <Button colorScheme="green" mt={4} >
  Continue to Payment
</Button>
          </Flex>
        )}
      </ModalContent>
    </Modal>
  );
};

export default BookAppointmentModal;
