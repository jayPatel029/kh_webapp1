import React, { useState, useEffect } from "react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Button,
} from "@chakra-ui/react";
import { BsTrash } from "react-icons/bs";
import { FaFilePdf } from "react-icons/fa6";
import UploadedFileModal from "./UploadedFileModal";
import MyModal from "./ShowModal";
import axiosInstance from "../../../axios/axiosInstance";
import { server_url } from "../../../constants/constants";
import formatDate from "../../../helpers/formatDate";

const LabTestsModal = ({ id, isOpen, onClose, userName }) => {
  const [showModal, setShowModal] = useState(false);
  const [labReportData, setLabReportData] = useState([]);
  const [uploadedFile, setUploadedFile] = useState(null);

  const openModal = () => {
    setShowModal(true);
  };

  const closeModal = (data) => {
    setShowModal(false);
  };

  const openFileModal = (id, imageUrl, comment) => {
    setUploadedFile({ id, imageUrl, comment });
  };

  const closeFileModal = () => {
    setUploadedFile(null);
  };

  const deleteLabReport = async (id) => {
    const isConfirmed = window.confirm("Are you sure you want to delete this lab report?");
    if (isConfirmed) {
      try {
        await axiosInstance.delete(`${server_url}/labreport/deleteLabReport/${id}`);
        await fetchData();
      } catch (error) {
        console.error("Error deleting lab report:", error);
        alert("Failed to delete lab report. Please try again.");
      }
    }
  };

  const fetchData = async () => {
    try {
      const response = await axiosInstance.get(`${server_url}/labreport/getLabReports/${id}`);
      setLabReportData(response.data.data);
    } catch (error) {
      console.error("Error fetching lab report data:", error);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchData();
    }
  }, [isOpen]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="xl">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Lab Tests</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <div className="container mx-auto p-4">
            <div className="bg-gray-100 py-4 px-4 md:px-10">
              <div className="manage-roles-container p-4 bg-white shadow-md border-t-4 border-primary">
                <div className="mt-4 mb-4 flex items-center justify-between">
                  <h1 className="text-xl font-bold">{userName}</h1>
                </div>
                <div className="flex justify-between items-center border-b pb-2 mb-4">
                  <h2 className="text-2xl font-bold">User Lab Report</h2>
                  <div className="flex items-center">
                    <Button
                      className="text-primary bg-gray border-primary"
                      onClick={openModal}
                    >
                      Upload Lab Report
                    </Button>
                    {showModal && (
                      <MyModal
                        closeModal={closeModal}
                        user_id={id}
                        onSuccess={fetchData}
                      />
                    )}
                    {uploadedFile && (
                      <UploadedFileModal
                        closeModal={closeFileModal}
                        user_id={id}
                        file_id={uploadedFile.id}
                        file={uploadedFile}
                      />
                    )}
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead className="bg-white text-gray-700">
                      <tr className="border-b-2 border-black">
                        <th className="py-3 px-4 text-left">Date</th>
                        <th className="py-3 px-4 text-center">Report Type</th>
                        <th className="py-3 px-4 text-center">Lab Reports</th>
                        <th className="py-3 px-4 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Array.isArray(labReportData) &&
                        labReportData.map((labReportsItem, index) => (
                          <tr
                            key={index}
                            className={`
                              ${localStorage.getItem("labReportId") === String(labReportsItem.id) ? "bg-green-100" : ""}
                              border-b border-gray-200
                            `}
                          >
                            <td>{formatDate(labReportsItem.Date)}</td>
                            <td className="py-3 px-4 text-center">{labReportsItem.Report_Type}</td>
                            <td className="flex justify-center">
                              {labReportsItem.Lab_Report && labReportsItem.Lab_Report.endsWith(".pdf") ? (
                                <FaFilePdf
                                  className="w-20 h-16 cursor-pointer py-3 text-red-500"
                                  onClick={() => openFileModal(labReportsItem.id, labReportsItem.Lab_Report)}
                                />
                              ) : (
                                <img
                                  src={labReportsItem.Lab_Report}
                                  alt="Lab Report"
                                  className="h-20 w-20 inline-block"
                                  style={{ cursor: "pointer" }}
                                  onClick={() => openFileModal(labReportsItem.id, labReportsItem.Lab_Report)}
                                />
                              )}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <button
                                className="text-red-500"
                                style={{ fontSize: "1.5rem" }}
                                onClick={() => deleteLabReport(labReportsItem.id)}
                              >
                                <BsTrash />
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                  {!Array.isArray(labReportData) && (
                    <div className="text-left italic font-light">No data present</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default LabTestsModal;
