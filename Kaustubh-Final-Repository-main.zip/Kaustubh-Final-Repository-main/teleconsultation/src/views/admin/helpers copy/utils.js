import { dummyadmin } from "../assets";


export default function getValidImageUrl(url) {
    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
    const isValidUrl = urlRegex.test(url);
    const profilePhotoUrl = isValidUrl ? url : dummyadmin;
    return profilePhotoUrl;
}

export const formatDate = (dateString) => {
    // Assuming dateString is in "yyyy-mm-dd" format
    const [year, month, day] = dateString.split('-');
    return `${day}/${month}/${year}`;
};