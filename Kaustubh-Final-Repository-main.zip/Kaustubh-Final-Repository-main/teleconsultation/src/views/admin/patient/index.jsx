import React, { useState, useEffect } from "react";
import {
  Avatar,
  Box,
  Flex,
  FormLabel,
  Icon,
  Input,
  Select,
  SimpleGrid,
  useColorModeValue,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
  Textarea,
} from "@chakra-ui/react";
import { MdAddTask, MdAttachMoney, MdBarChart, MdFileCopy } from "react-icons/md";
import axiosInstance from "../axios/axiosInstance"
import ComplexTable from "views/admin/default/components/ComplexTable";
import { columnsDataComplex } from "views/admin/default/variables/columnsData";

export default function UserReports() {
  // Chakra Color Mode
  const brandColor = useColorModeValue("brand.500", "white");
  const boxBg = useColorModeValue("secondaryGray.300", "whiteAlpha.100");

  const { isOpen, onOpen, onClose } = useDisclosure();
  const { isOpen: isFormOpen, onOpen: onFormOpen, onClose: onFormClose } = useDisclosure();
  const [selectedLabTest, setSelectedLabTest] = useState(null);
  const [patientsData, setPatientsData] = useState([]);
  const [newPatientData, setNewPatientData] = useState({
    id: "",
    profilePhoto: null,
    name: "",
    age: "",
    gender: "",
    email: "",
    phoneNumber: "",
    test: "",
    date: "",
    result: "",
    pastAppointments: "",
  });
 
  useEffect(() => {
    const fetchPatientsData = async () => {
      try {
        const response = await axiosInstance.get("http://localhost:8080/api/patient/getPatients");
        setPatientsData(response.data.data);
      } catch (error) {
        console.error("Error fetching patients data:", error);
      }
    };

    fetchPatientsData();
  }, []);

  const handleLabTestClick = (labTest) => {
    setSelectedLabTest(labTest);
    onOpen();
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewPatientData({ ...newPatientData, [name]: value });
  };

  const handleFileChange = (e) => {
    setNewPatientData({ ...newPatientData, profilePhoto: e.target.files[0] });
  };

  const handleAddPatient = async () => {
    try {
      const formData = new FormData();
      formData.append("id", newPatientData.id);
      if (newPatientData.profilePhoto) {
        formData.append("profilePhoto", newPatientData.profilePhoto);
      }
      formData.append("name", newPatientData.name);
      formData.append("age", newPatientData.age);
      formData.append("gender", newPatientData.gender);
      formData.append("email", newPatientData.email);
      formData.append("number", newPatientData.phoneNumber);
      formData.append("test", newPatientData.test);
      formData.append("date", newPatientData.date);
      formData.append("result", newPatientData.result);
      formData.append("pastAppointments", newPatientData.pastAppointments);
  
      await axiosInstance.post("http://localhost:8080/api/patient/AddPatient", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      // Fetch updated patients data after adding new patient
      const response = await axiosInstance.get("http://localhost:8080/api/patient/getPatients");
      setPatientsData(response.data.data);
      onFormClose();
    } catch (error) {
      console.error("Error adding new patient:", error);
    }
  };

  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }} w="100%" overflowX="auto">
      <SimpleGrid columns={1} gap="20px" mb="20px">
        <ComplexTable 
          columnsData={columnsDataComplex}
          tableData={patientsData}
          onLabTestClick={handleLabTestClick}
        />
      </SimpleGrid>

      <Flex justify="flex-end">
        <Button colorScheme="teal" onClick={onFormOpen}>
          Add Patient
        </Button>
      </Flex>

      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Lab Test Report</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            {selectedLabTest && (
              <Table variant="simple">
                <Thead>
                  <Tr>
                    <Th>Date</Th>
                    <Th>Report</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {selectedLabTest.reports.map((report, index) => (
                    <Tr key={index}>
                      <Td>{report.date}</Td>
                      <Td>{report.details}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            )}
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={onClose}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>

      <Modal isOpen={isFormOpen} onClose={onFormClose}>
        <ModalOverlay />
        <ModalContent maxW="600px">
          <ModalHeader>Add New Patient</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Patient ID</FormLabel>
                <Input
                  placeholder="Patient ID"
                  name="id"
                 
                  onChange={handleInputChange}
                />
              </Box>
              <Box flex="1">
                <FormLabel>Profile Photo</FormLabel>
                <Input
                  type="file"
                  name="profilePhoto"
                  onChange={handleFileChange}
                />
              </Box>
            </Flex>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Name</FormLabel>
                <Input
                  placeholder="Name"
                  name="name"
                  
                  onChange={handleInputChange}
                />
              </Box>
              <Box flex="1">
                <FormLabel>Age</FormLabel>
                <Input
                  placeholder="Age"
                  name="age"
                 
                  onChange={handleInputChange}
                />
              </Box>
            </Flex>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Gender</FormLabel>
                <Select
                  placeholder="Select gender"
                  name="gender"
                  value={newPatientData.gender}
                  onChange={handleInputChange}
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </Select>
              </Box>
              <Box flex="1">
                <FormLabel>Email</FormLabel>
                <Input
                  placeholder="Email"
                  name="email"
                  type="email"
                  value={newPatientData.email}
                  onChange={handleInputChange}
                />
              </Box>
            </Flex>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Phone Number</FormLabel>
                <Input
                  placeholder="Phone Number"
                  name="phoneNumber"
                  type="tel"
                  value={newPatientData.number}
                  onChange={handleInputChange}
                />
              </Box>
              <Box flex="1">
                <FormLabel>Lab Test</FormLabel>
                <Input
                  placeholder="Test"
                  name="test"
                  value={newPatientData.test}
                  onChange={handleInputChange}
                />
              </Box>
            </Flex>
            <Flex mb={4} gap={4}>
              <Box flex="1">
                <FormLabel>Date</FormLabel>
                <Input
                  type="date"
                  name="date"
                  value={newPatientData.dob}
                  onChange={handleInputChange}
                />
              </Box>
            </Flex>
            <FormLabel>Past Appointments</FormLabel>
            <Textarea
              placeholder="Past Appointments"
              name="pastAppointments"
              value={newPatientData.pastAppointments}
              onChange={handleInputChange}
              width="100%"
              mb={4}
            />
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={handleAddPatient}>
              Add
            </Button>
            <Button variant="ghost" onClick={onFormClose}>
              Cancel
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
}
